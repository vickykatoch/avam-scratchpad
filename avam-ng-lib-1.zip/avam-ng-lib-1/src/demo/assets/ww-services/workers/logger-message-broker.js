System.register(["./index"], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var index_1, LoggerMessageBroker;
    return {
        setters: [
            function (index_1_1) {
                index_1 = index_1_1;
            }
        ],
        execute: function () {
            LoggerMessageBroker = class LoggerMessageBroker {
                get messageType() {
                    return index_1.WorkerMessageType;
                }
                onMessage(message) {
                    console.log(message.payload);
                }
            };
            exports_1("LoggerMessageBroker", LoggerMessageBroker);
        }
    };
});
//# sourceMappingURL=logger-message-broker.js.map