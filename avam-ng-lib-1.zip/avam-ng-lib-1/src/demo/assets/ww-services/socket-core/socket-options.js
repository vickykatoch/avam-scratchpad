System.register([], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var SocketType;
    return {
        setters: [],
        execute: function () {
            exports_1("SocketType", SocketType = Object.freeze({
                AMPS: 0,
                SOCKET_IO: 1
            }));
        }
    };
});
//# sourceMappingURL=socket-options.js.map