System.register([], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var LoggerFactory;
    return {
        setters: [],
        execute: function () {
            LoggerFactory = class LoggerFactory {
                static getLogger() {
                    throw new Error('Not implemented');
                }
            };
            exports_1("LoggerFactory", LoggerFactory);
        }
    };
});
//# sourceMappingURL=logger.factory.js.map