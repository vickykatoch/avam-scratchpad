"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocketType = Object.freeze({
    AMPS: 0,
    SOCKET_IO: 1
});
//# sourceMappingURL=socket-options.js.map