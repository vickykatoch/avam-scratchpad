"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=socket.interface.js.map