"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var index_1 = require("./index");
var LoggerMessageBroker = (function () {
    function LoggerMessageBroker() {
    }
    Object.defineProperty(LoggerMessageBroker.prototype, "messageType", {
        get: function () {
            return index_1.WorkerMessageType;
        },
        enumerable: true,
        configurable: true
    });
    LoggerMessageBroker.prototype.onMessage = function (message) {
        console.log(message.payload);
    };
    return LoggerMessageBroker;
}());
exports.LoggerMessageBroker = LoggerMessageBroker;
//# sourceMappingURL=logger-message-broker.js.map