"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var worker_message_1 = require("./worker-message");
var socket_controller_1 = require("../socket-controllers/socket-controller");
var SocketMessageBroker = (function () {
    function SocketMessageBroker() {
        this.socketsController = new socket_controller_1.SocketsController();
    }
    Object.defineProperty(SocketMessageBroker.prototype, "messageType", {
        get: function () {
            return worker_message_1.WorkerMessageType;
        },
        enumerable: true,
        configurable: true
    });
    SocketMessageBroker.prototype.onMessage = function (message) {
        switch (message.type.toUpperCase()) {
            case worker_message_1.WorkerMessageType.SOCKET_CONNECT:
                this.socketsController.connect(message.payload);
                break;
            case worker_message_1.WorkerMessageType.SOCKET_SUBSCRIBE:
                this.socketsController.subscribe(message.payload);
                break;
            case worker_message_1.WorkerMessageType.SOCKET_PUBLISH:
                this.socketsController.publish(message.payload);
                break;
            case worker_message_1.WorkerMessageType.SOCKET_TOPIC_UNSUBSCRIBE:
                this.socketsController.unsubscribe(message.payload);
                break;
            case worker_message_1.WorkerMessageType.SOCKET_PUBLISH:
                this.socketsController.publish(message.payload);
                break;
            case worker_message_1.WorkerMessageType.SOCKET_DISCONNECT:
                this.socketsController.disconnect(message.payload);
                break;
            case worker_message_1.WorkerMessageType.SOCKET_DISCONNECT_ALL:
                this.socketsController.dispose();
                break;
        }
    };
    return SocketMessageBroker;
}());
exports.SocketMessageBroker = SocketMessageBroker;
//# sourceMappingURL=socket-message-broker.js.map