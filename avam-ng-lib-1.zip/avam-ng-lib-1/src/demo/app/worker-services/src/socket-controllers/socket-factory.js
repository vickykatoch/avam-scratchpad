"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var socket_options_1 = require("../socket-core/socket-options");
var amps_socket_service_provider_1 = require("../socket-providers/amps/amps-socket.service.provider");
var socket_io_service_provider_1 = require("../socket-providers/socketio/socket-io.service.provider");
var SocketFactory = (function () {
    function SocketFactory() {
    }
    SocketFactory.createSocket = function (options) {
        SocketFactory.validateSocketParams(options);
        var socket;
        switch (options.type) {
            case socket_options_1.SocketType.AMPS:
                socket = new amps_socket_service_provider_1.AmpsSocketServiceProvider(options);
                break;
            case socket_options_1.SocketType.SOCKET_IO:
                socket = new socket_io_service_provider_1.SocketIOServiceProvider(options);
        }
        return socket;
    };
    SocketFactory.validateSocketParams = function (options) {
        // Guard.throwIfTrue()   
    };
    return SocketFactory;
}());
exports.SocketFactory = SocketFactory;
//# sourceMappingURL=socket-factory.js.map