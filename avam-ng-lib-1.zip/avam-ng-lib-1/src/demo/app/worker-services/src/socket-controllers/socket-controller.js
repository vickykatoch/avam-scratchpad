"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var socket_factory_1 = require("./socket-factory");
var SocketsController = (function () {
    function SocketsController() {
        this.socketConnections = {};
    }
    /**
     * Connects to socket
     * @param options :
     */
    SocketsController.prototype.connect = function (options) {
        try {
            if (Array.isArray(options)) {
            }
            else {
                var socket = socket_factory_1.SocketFactory.createSocket(options);
                // socket.connect().then(x=> x.subscribe(options.topic));
            }
        }
        catch (err) {
            console.error(err);
        }
    };
    /**
     * Subscribe to one or multiple topic(s)
     * @param options
     */
    SocketsController.prototype.subscribe = function (options) {
        try {
        }
        catch (error) {
        }
    };
    SocketsController.prototype.unsubscribe = function (options) {
        try {
        }
        catch (error) {
        }
    };
    /**
     * Publishes message on a topic
     * @param options
     */
    SocketsController.prototype.publish = function (options) {
    };
    /**
     * Disconnects a socket
     * @param options
     */
    SocketsController.prototype.disconnect = function (options) {
    };
    /**
     * Disposes socket object and disconnect all connections
     */
    SocketsController.prototype.dispose = function () {
    };
    return SocketsController;
}());
exports.SocketsController = SocketsController;
//# sourceMappingURL=socket-controller.js.map