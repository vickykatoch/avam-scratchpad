"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LoggerFactory = (function () {
    function LoggerFactory() {
    }
    LoggerFactory.getLogger = function () {
        throw new Error('Not implemented');
    };
    return LoggerFactory;
}());
exports.LoggerFactory = LoggerFactory;
//# sourceMappingURL=logger.factory.js.map