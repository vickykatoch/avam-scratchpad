import { LoggerInterface } from "./logger.interface";

export class LoggerFactory {
    public static getLogger() : LoggerInterface {
        throw new Error('Not implemented');
    }
}