export interface LoggerInterface {
    info() : void;
    debug() : void;
    error() : void;
    error() : void;
}