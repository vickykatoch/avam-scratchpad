"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MODULE_NAME = 'SocketIOServiceProvider';
var SocketIOServiceProvider = (function () {
    function SocketIOServiceProvider(options) {
        this.options = options;
        this.topics = {};
    }
    SocketIOServiceProvider.prototype.connect = function () {
        return new Promise(function (resolve, reject) {
            // resolve(this);
        });
    };
    SocketIOServiceProvider.prototype.subscribe = function (options) {
        if (!(options.topic in this.topics)) {
            console.log("[" + MODULE_NAME + "]=>Subscribed to " + options.topic);
        }
    };
    SocketIOServiceProvider.prototype.unsubscribe = function (options) {
        if (!(options.topic in this.topics)) {
            console.log("[" + MODULE_NAME + "]=>Unsubscribed from " + options.topic);
            delete this.topics[options.topic];
        }
    };
    SocketIOServiceProvider.prototype.publish = function (options) {
        console.log("[" + MODULE_NAME + "]=>Published to " + options.topic);
    };
    return SocketIOServiceProvider;
}());
exports.SocketIOServiceProvider = SocketIOServiceProvider;
//# sourceMappingURL=socket-io.service.provider.js.map