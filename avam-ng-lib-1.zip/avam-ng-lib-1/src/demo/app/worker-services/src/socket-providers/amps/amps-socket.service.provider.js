"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MODULE_NAME = 'AmpsSocketServiceProvider';
var WebWorkerContext;
var AmpsSocketServiceProvider = (function () {
    function AmpsSocketServiceProvider(options) {
        this.options = options;
    }
    AmpsSocketServiceProvider.prototype.connect = function () {
        return new Promise(function (resolve, reject) {
            // resolve(this);
        });
    };
    AmpsSocketServiceProvider.prototype.subscribe = function (options) {
        // if(!(options.topic in this.topics)) {
        console.log("[" + MODULE_NAME + "]=>Subscribed to " + options.topic);
        // }
    };
    AmpsSocketServiceProvider.prototype.unsubscribe = function (options) {
        // if(!(options.topic in this.topics)) {
        console.log("[" + MODULE_NAME + "]=>Unsubscribed from " + options.topic);
        // delete this.topics[options.topic];
        // }        
    };
    AmpsSocketServiceProvider.prototype.publish = function (options) {
        console.log("[" + MODULE_NAME + "]=>Published to " + options.topic);
    };
    return AmpsSocketServiceProvider;
}());
exports.AmpsSocketServiceProvider = AmpsSocketServiceProvider;
//# sourceMappingURL=amps-socket.service.provider.js.map