"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Guard = (function () {
    function Guard() {
    }
    Guard.throwIfTrue = function (isTrue, message) {
        if (isTrue) {
            throw new Error(message);
        }
    };
    return Guard;
}());
exports.Guard = Guard;
//# sourceMappingURL=guard.js.map