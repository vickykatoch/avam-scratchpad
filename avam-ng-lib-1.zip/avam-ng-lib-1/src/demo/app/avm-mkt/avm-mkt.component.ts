import { Component } from "@angular/core";
import { AvmMktService } from "./services/avm-mkt.service";
import { ConfigService } from "./services/config.service";


@Component({
  selector: 'avm-mkt',
  providers : [ConfigService, AvmMktService],
  templateUrl: './avm-mkt.component.html'
})
export class AvmMktComponent {
    constructor(private dataService : AvmMktService) {
        
    }
}