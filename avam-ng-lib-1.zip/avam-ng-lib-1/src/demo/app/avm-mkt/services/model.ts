export interface EmpData {
    id : number;
    name : string;    
}