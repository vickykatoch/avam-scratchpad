import { Injectable } from "@angular/core";

@Injectable()
export class ConfigService {
    getMktConfig() : any {
        return {
            url : 'htto://localhost:8080',
            topic : 'MKT_DATA'
        };
    }
}