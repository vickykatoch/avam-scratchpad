import { Injectable } from "@angular/core";
import { WorkerMessage, WorkerMessageType } from "../../worker-services/index";


@Injectable()
export class WebSocketWorkerService {
    private worker : Worker;
    private isWorkerRuning : boolean;

    constructor() {
        this.initializeWorker();
    }





    private initializeWorker() {
        this.worker = new Worker('assets/ww-services/socket-loader.js');
        this.worker.postMessage({ type: 'INIT_WORKER', payload : 'load dependencies'});
        this.worker.addEventListener('message',this.onDataReceivedFromWorker.bind(this));
    }
    private onDataReceivedFromWorker(evt: MessageEvent) {
        const message = <WorkerMessage>evt.data;
        switch(message.type) {
            case WorkerMessageType.WORKER_INITIALIZED:
                this.isWorkerRuning = true;
                break;
        }
    }
}