import { Injectable } from "@angular/core";
import { WebSocketWorkerService } from "./web-worker.service";
import { ConfigService } from "./config.service";
import { Subject } from "rxjs/Subject";
import { EmpData } from "app/avm-mkt/services/model";

@Injectable()
export class AvmMktService {
    private mktNotifier = new Subject<EmpData>();
    public mktData$ = this.mktNotifier.asObservable();
    
    constructor(private wswService: WebSocketWorkerService, private configService: ConfigService) {

    }

    

    
}