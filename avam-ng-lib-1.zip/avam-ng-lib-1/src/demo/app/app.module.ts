import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { LibModule } from 'quickstart-lib';

import { AppComponent }  from './app.component';
import { AvmMktComponent } from "./avm-mkt/avm-mkt.component";
import { WebSocketWorkerService } from "./avm-mkt/services/web-worker.service";


@NgModule({
  imports:      [ BrowserModule, LibModule],
  declarations: [ AppComponent, AvmMktComponent ],
  providers : [WebSocketWorkerService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
