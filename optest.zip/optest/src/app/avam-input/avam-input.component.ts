import { Component, OnInit } from '@angular/core';

let finWindowRef = (): any => window;

@Component({
  selector: 'avam-input',
  templateUrl: './avam-input.component.html',
  styleUrls: ['./avam-input.component.scss']
})
export class AvamInputComponent implements OnInit {
  private ctr: number = 0;
  private fin : any;
  constructor() { }

  ngOnInit() {
    this.fin = finWindowRef().fin;
  }

  onShowSameProcessWindow() {    
    let name = `dataWindow-${this.ctr}`;
    const url = this.ctr === 0 || (this.ctr/2 === 0) ? 'http://localhost:4200/assets/childwindow.html' : 'http://localhost:4200/assets/childwindow1.html';
    this.ctr++;

    if (this.fin && this.fin.desktop) {
      new this.fin.desktop.Window({
        name: name,
        url: url,
        defaultLeft: 10,
        defaultTop: 220,
        autoShow: true,
        defaultHeight: 100,
        defaultWidth : 100,
        defaultCentered: true,
        frame: false
      });
    }
  }
  onShowAnotherProcessWindow() {
   
    const app = new this.fin.desktop.Application({
      "name": "NewApp",
      "url": "http://localhost:4200/index.html",
      "uuid": "OpenFin22 Webinar-udbrf2",
      "autoShow": true,
      "defaultCentered": true,
      "icon": "http://localhost:4200/favicon.ico",
      "frame": true,
      "defaultHeight": 300,
      "defaultWidth": 300,
      "alwaysOnTop": false,
    }, () => {
      console.log('success');
    }, error => {
      console.error(error);
    });
    app.run();
  }
  bringToFront() {
    setTimeout(() => {
     
      this.fin.desktop.Application.getCurrent().window.setAsForground();
      this.fin.desktop.Application.getCurrent().window.flash();
      console.log('Braught');
    },1000);
  }
}
