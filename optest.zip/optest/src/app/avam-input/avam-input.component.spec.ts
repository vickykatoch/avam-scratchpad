import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvamInputComponent } from './avam-input.component';

describe('AvamInputComponent', () => {
  let component: AvamInputComponent;
  let fixture: ComponentFixture<AvamInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvamInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvamInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
