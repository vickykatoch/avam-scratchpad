import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvamCheckComponent } from './avam-check.component';

describe('AvamCheckComponent', () => {
  let component: AvamCheckComponent;
  let fixture: ComponentFixture<AvamCheckComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvamCheckComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvamCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
