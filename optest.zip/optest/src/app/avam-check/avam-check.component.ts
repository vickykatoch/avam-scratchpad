import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'avam-check',
  templateUrl: './avam-check.component.html',
  styleUrls: ['./avam-check.component.scss']
})
export class AvamCheckComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
