import { OpenfinTestPage } from './app.po';

describe('openfin-test App', () => {
  let page: OpenfinTestPage;

  beforeEach(() => {
    page = new OpenfinTestPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
