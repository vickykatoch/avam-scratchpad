export interface IOrder {
      symbol            : string;
      orderId           : string;
      exDestination     : string;
      lastMarket        : string;
      profile           : string;
      side              : string;
      qtyTotal          : number;
      leavesQty         : number;
      orderStatus       : string;
      transactionTime   : number;
      price             : number;
      lastPrice         : number;
      orderType         : string;
      sendingTime       : number;
      qtyShown          : number;
      cumQty            : number;
      lastQty           : number;
      avgPrice          : number;
      tradedPercentage  : number;
      text?              : string;
      isActive          : boolean;
      clOrdId?           : string;
      origClOrdId?       : string;
      strategy?          : string;
      account?           : string;
      portfolio?        : string;
}