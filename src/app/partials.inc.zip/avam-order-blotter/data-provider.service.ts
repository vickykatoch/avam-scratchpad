import { Utils } from './../utils/Utils';
import { IOrder } from './model';
import { Injectable } from '@angular/core';

const STATUS_LIST             = ['NEW', 'FILLED', 'CANCELLED', 'PARTIALLY_FILLED', 'SUSPENDED', 'PENDING', 'REJECTED'];
const SIDES                   = ['BUY','SELL'];
const DESTINATION_LIST        = ['ESPD','XCME','SONAR','SOR-CASH','SOR','DWEB','BTEC','SPREADER','SOR-FUTURE', 'SPREADER','SPREADER-FUTURE','QMM', 'XHUB','XHUB-TSY'];
const SYMBOLS                 = ['2_YEAR', '3_YEAR','5_YEAR', '7_YEAR','10_YEAR', '30_YEAR', 'ED1', 'ED2', 'ED3', 'ED4', 'ED5', 'ED6', 'ED7', 'ED8'];
const ORDER_TYPES             = ['ONE','TWO'];

@Injectable()
export class ClientDataProviderService {
      private orders: IOrder[] = [];

      getRandomData(count? : number) : IOrder[] {
            count = count || 5;
            return this.generateNewOrderData(2);
      }

      private generateNewOrderData(count: number) : IOrder[] {
            return <IOrder[]>[{
                  symbol            : this.getRandomValueFromArray(SYMBOLS),
                  orderId           : this.generateUUID(),
                  exDestination     : this.getRandomValueFromArray(DESTINATION_LIST),
                  lastMarket        : '',
                  profile           : '',
                  side              : this.getRandomValueFromArray(SIDES),
                  qtyTotal          : this.getRandomNumber(1,100),
                  leavesQty         : this.getRandomNumber(1,100),
                  orderStatus       : this.getRandomValueFromArray(STATUS_LIST),
                  transactionTime   : Date.now(),
                  price             : this.getRandomNumber(99.30,103.75, true),
                  lastPrice         : this.getRandomNumber(99.30,103.75, true),
                  orderType         : this.getRandomValueFromArray(ORDER_TYPES),
                  sendingTime       : Date.now(),
                  qtyShown          : this.getRandomNumber(1,100),
                  cumQty            : this.getRandomNumber(1,100),
                  lastQty           : this.getRandomNumber(1,100),
                  avgPrice          : this.getRandomNumber(99.30,103.75, true),
                  tradedPercentage  : this.getRandomNumber(1,100),

                  text              : '',
                  isActive          : true,
                  clOrdId           : '',
                  origClOrdId       : '',
                  strategy          : '',
                  account           : '',
                  portfolio         : ''                 
            }];
      }
      private getRandomValueFromArray(array: any[]) : any {
            const index = Utils.getRandomNum(0,array.length);
            return array[index];
      }
      private generateOrderId() {
            return '';
      }
      private getRandomNumber(min: number, max: number, dec?: boolean) : number {
            return Math.floor((Math.random() * max) + min);
      }
      private generateUUID () { // Public Domain/MIT
            let d = new Date().getTime();
            if (typeof performance !== 'undefined' && typeof performance.now === 'function'){
                  d += performance.now(); //use high-precision timer if available
            }
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                  var r = (d + Math.random() * 16) % 16 | 0;
                  d = Math.floor(d / 16);
                  return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            });
      }
}